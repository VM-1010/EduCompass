package com.educompass;

public class Main {
    public static void main(String[] args) {
        YoutubeLinkResource yt = new YoutubeLinkResource(Subject.Python, "https://youtu.be/rfscVS0vtbw?si=8JX2HBZRFR3RJIhF", Semester.S1);
        yt.followURL(); // opens the url in browser
    }
}
