package com.educompass;

import java.time.LocalDate;

public class Resource {
    LocalDate dateadded;
    Subject subject;
    Semester semester;
}
