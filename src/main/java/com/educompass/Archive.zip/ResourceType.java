package com.educompass;

public enum ResourceType {
    PDF_Notes,
    Youtube_Link,
    Online_Resource,
    Online_Course,
    External_Website,
}
