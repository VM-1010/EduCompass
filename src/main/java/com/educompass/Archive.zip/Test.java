package com.educompass;

public class Test {
    public static void main(String[] args) {
        YoutubeLinkResource yt = new YoutubeLinkResource(Subject.Python, "https://www.youtube.com", Semester.S1);
        yt.followURL();
    }
}
