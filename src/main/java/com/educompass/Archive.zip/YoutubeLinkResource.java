package com.educompass;
import java.time.LocalDate;
import java.net.URI;
import java.net.URL;
import java.awt.Desktop;

public class YoutubeLinkResource extends Resource {
    URI VideoLink;
    public YoutubeLinkResource(Subject s, String url, Semester sem) {
        super.subject = s;
        super.semester = sem;
        super.dateadded = LocalDate.now();
        try {
            this.VideoLink = new URL(url).toURI();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getUrl() {
        return VideoLink.toString();
    }

    public void followURL() {
        //Desktop d = Desktop.getDesktop();
        try {
            if (Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))
                Desktop.getDesktop().browse(VideoLink);
            else // fallback if desktop doesn't support the `BROWSE` Action, then xdg-open is used
                Runtime.getRuntime().exec(new String[]{"xdg-open", this.getUrl()}); 
        } 
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
